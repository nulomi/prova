/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a1_estroctures_condicionals;

import java.util.Scanner;

/**
 *
 * @author nlo7503
 */
public class ex10 {
    public static void main(String[] args) {
        String nom=new string
        double hores,salB,salN;
        Scanner entrada = new Scanner(System.in);
        System.out.print("introdueix el valor de hores actuals ");
        nom = entrada.nextLine();
        System.out.print("introdueix el valor de hores actuals ");
        hores = entrada.nextDouble();
        if(hores=<130){
        salB=hores*15;
                  if(salB=<500){
                  salN=salB
                  System.out.print("el teu salari net ha sigu"+salN);
                  }
                  else{
                        if(salB=<900){
                        salN=500+(salB-500)*0.75
                        System.out.print("el teu salari net ha sigu"+salN);
                        } 
                        else{
                                if(salB>900){
                                 salN=500+(400*0.75)+(salarB-900)*0.55   
                                 System.out.print("el teu salari net ha sigu"+salN);
                                 }
                                 else{
                                 System.out.print("es incorrecte")  
                                 }
                          }
                  }
        } else {
         salB=130+(hores-130)*22.5;       
                if(salB=<500){
                      salN=salB
                      System.out.print("el teu salari net ha sigu"+salN);
                      }
                      else{
                            if(salB=<900){
                            salN=500+(salB-500)*0.75;
                            System.out.print("el teu salari net ha sigu"+salN);
                            } 
                            else{
                                    if(salB>900){
                                     salN=500+(400*0.75)+(salarB-900)*0.55;   
                                     System.out.print("el teu salari net ha sigu"+salN);
                                     }
                                     else{
                                     System.out.print("es incorrecte")  
                                     }
                              }
                      }
                }

    }
    }

 

    
