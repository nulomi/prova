/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a1_estroctures_bucles;

import java.util.Scanner;

/**
 *
 * @author nlo7503
 */
public class ex3 {
    public static void main(String[] args) {
        int num1,num2,suma=0;
        Scanner in=new Scanner(System.in);
        System.out.println("Introdueix numero 1: ");
        num1=in.nextInt();
        System.out.println("Introdueix numero 2: ");
        suma=1+num1;
        
    }
    
}
